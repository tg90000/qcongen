"""Command line interface for QConGen."""

import argparse
import logging
import sys
from pathlib import Path
from typing import NoReturn

from qcongen.config import initialize_config
from qcongen.engine.constraint_gen import run_constraint_gen
from qcongen.io.config_reader import read_config, BatchConfig, QConGenConfig, setup_batch_run
from qcongen.io.input_reader import MPS_to_BLP
from qcongen.io.output_writer import create_output_directory
from qcongen.utils.reference_partition import solve_mps_with_ortools
from qcongen.utils.generators import generate_random_instance
from qcongen.utils.logging import setup_logging

# Get the package logger
logger = logging.getLogger('qcongen')

def run_single_instance(
    config: QConGenConfig,
    tau: float,
    max_iters: int,
    use_ref: bool,
    output_dir: Path | None = None,
) -> tuple[bool, list[int], float]:
    """Run QConGen on a single instance.
    
    Args:
        config: Configuration for the run
        tau: Threshold for adding constraints
        max_iters: Maximum number of iterations
        use_ref: Whether to use the reference solver
        output_dir: Optional output directory (if None, creates timestamped dir)
        
    Returns:
        tuple containing:
            bool: True if feasible solution found
            list[int]: The solution if found, empty list otherwise
            float: The objective value if found, INF otherwise
    """
    # Create output directory if not provided
    if output_dir is None:
        output_dir = create_output_directory()
    
    # Setup logging for this run
    setup_logging(output_dir)

    # Read problem based on input type
    if config.input_type == "mps":
        if use_ref:
            # Use classical reference solver
            success, solution, value = solve_mps_with_ortools(config.input_file_path_resolved)
        else:
            # Use quantum algorithm
            blp = MPS_to_BLP(config.input_file_path_resolved)
            success, solution, value = run_constraint_gen(
                blp=blp,
                sample_size=config.sample_size,
                tau=tau,
                max_iters=max_iters,
                log_dir=output_dir,
            )
    elif config.input_type == "random":
        # Generate random instance
        if config.random_instance is None:
            # Use defaults if no parameters provided
            blp = generate_random_instance(output_dir=output_dir)
        else:
            # Use provided parameters
            blp = generate_random_instance(
                n_sets=config.random_instance.n_sets,
                n_elements=config.random_instance.n_elements,
                n_constraints=config.random_instance.n_constraints,
                instance_name=config.random_instance.instance_name,
                output_dir=output_dir,
            )
        
        if use_ref:
            # Use classical reference solver on the generated instance
            instance_path = output_dir / f"{config.random_instance.instance_name if config.random_instance else 'random'}.mps"
            success, solution, value = solve_mps_with_ortools(instance_path)
        else:
            # Use quantum algorithm on the generated instance
            success, solution, value = run_constraint_gen(
                blp=blp,
                sample_size=config.sample_size,
                tau=tau,
                max_iters=max_iters,
                log_dir=output_dir,
            )
    else:
        raise ValueError(f"Unsupported input type: {config.input_type}")

    return success, solution, value

def main() -> NoReturn:
    """Main entry point for QConGen CLI.
    
    Example usage:
        # Single run with configuration file:
        qcongen config.json
        
        # Example config.json for single run:
        {
            "input_type": "mps",  # or "random"
            "input_file_path": "input/set_partition_mps/problem15_60.mps",  # for mps type
            "sample_size": 1000,
            "random_instance": {  # for random type
                "n_sets": 15,
                "n_elements": 25,
                "n_constraints": 50,
                "instance_name": "random"
            }
        }
        
        # Example config.json for batch run:
        {
            "batch_name": "experiment1",  # optional
            "configs": [
                {
                    "input_type": "random",
                    "sample_size": 1000,
                    "random_instance": {
                        "n_sets": 15,
                        "n_elements": 25,
                        "instance_name": "random1"
                    }
                },
                {
                    "input_type": "mps",
                    "sample_size": 2000,
                    "input_file_path": "input/set_partition_mps/problem15_60.mps"
                }
            ]
        }
        
        # Additional options:
        qcongen config.json --tau 0.1 --max-iters 500
        
        # Run with classical reference solver:
        qcongen config.json --ref
    """
    parser = argparse.ArgumentParser(description="QConGen: Quantum Constraint Generation Algorithm")

    parser.add_argument("config_file", type=Path, help="Path to configuration JSON file")

    parser.add_argument(
        "--tau",
        "-t",
        type=float,
        default=0.0,
        help="Threshold for adding constraints (default: 0.0)",
    )

    parser.add_argument(
        "--max-iters",
        "-m",
        type=int,
        default=1000,
        help="Maximum number of iterations (default: 1000)",
    )

    parser.add_argument(
        "--ibm-token",
        type=str,
        help="IBM Quantum token (overrides IBM_TOKEN environment variable)",
    )
    
    parser.add_argument(
        "--ref",
        action="store_true",
        help="Use classical reference solver (OR-Tools) instead of quantum algorithm",
    )

    args = parser.parse_args()

    try:
        # Read and validate configuration
        config = read_config(args.config_file)

        # Initialize configuration
        initialize_config(ibm_token=args.ibm_token)

        # Handle batch configuration
        if isinstance(config, BatchConfig):
            # Create batch directory structure
            batch_dir = setup_batch_run(config)
            logger.info(f"\nStarting batch run in {batch_dir}")

            # Run each configuration
            for i, run_config in enumerate(config.configs, 1):
                run_dir = batch_dir / str(i)
                logger.info(f"\nRunning instance {i}/{len(config.configs)}")
                
                success, solution, value = run_single_instance(
                    config=run_config,
                    tau=args.tau,
                    max_iters=args.max_iters,
                    use_ref=args.ref,
                    output_dir=run_dir,
                )

                # Print result to console
                if success:
                    print(f"\nInstance {i}: Found solution with value: {value}")
                    print(f"Solution: {solution}")
                else:
                    print(f"\nInstance {i}: No feasible solution found")

            print(f"\nBatch run completed. Results saved in: {batch_dir}")
        else:
            # Single run
            success, solution, value = run_single_instance(
                config=config,
                tau=args.tau,
                max_iters=args.max_iters,
                use_ref=args.ref,
            )

            # Print result to console
            if success:
                print(f"\nFound solution with value: {value}")
                print(f"Solution: {solution}")
            else:
                print("\nNo feasible solution found")

        sys.exit(0)
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
