# QConGen

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![NumPy](https://img.shields.io/badge/numpy-2.2.2-green.svg)](https://numpy.org/)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Ruff](https://img.shields.io/badge/ruff-0.9.4-red.svg)](https://github.com/astral-sh/ruff)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Quantum-based constraint generation optimization algorithm for solving binary linear programming problems, with a focus on set partitioning problems.

## Installation

Install from source:

```sh
git clone https://github.com/yourusername/qcongen.git
cd qcongen
pip install -e .
```

## Usage

QConGen can solve set partitioning problems using either a quantum algorithm (default) or a classical solver (OR-Tools). You can use either pre-defined MPS files or generate random instances.

### Running with Configuration File

QConGen supports both single instance and batch processing modes:

```sh
# Single instance
qcongen config.json [options]

# Batch processing
qcongen batch_config.json [options]
```

#### Configuration File Format

1. Single Instance (config.json):
```json
{
    "input_type": "mps",
    "input_file_path": "input/set_partition_mps/problem15_60.mps",
    "sample_size": 1000
}
```

2. Random Instance:
```json
{
    "input_type": "random",
    "sample_size": 1000,
    "random_instance": {
        "n_sets": 15,          # Number of sets (default: 15)
        "n_elements": 25,      # Number of elements (default: 25)
        "n_constraints": 50,   # Number of constraints (default: 50)
        "min_set_size": 1,     # Minimum set size (default: 1)
        "max_set_size": 10,    # Maximum set size (default: 10)
        "min_cost": 1,         # Minimum cost (default: 1)
        "max_cost": 100,       # Maximum cost (default: 100)
        "instance_name": "random"  # Instance name (default: "random")
    }
}
```

3. Batch Processing (batch_config.json):
```json
{
    "batch_name": "experiment1",  # Optional name for the batch
    "configs": [
        {
            "input_type": "random",
            "sample_size": 1000,
            "random_instance": {
                "n_sets": 15,
                "n_elements": 25,
                "instance_name": "random1"
            }
        },
        {
            "input_type": "mps",
            "sample_size": 2000,
            "input_file_path": "input/set_partition_mps/problem15_60.mps"
        }
    ]
}
```

Required fields:
- `input_type`: Type of input ("mps" or "random")
- `sample_size`: Number of samples for quantum algorithm
- `input_file_path`: Path to MPS file (required for "mps" type)
- `random_instance`: Random instance parameters (optional for "random" type, defaults shown above)
- For batch processing: `configs` array containing multiple configurations

### Example Configuration Files

The repository includes example configuration files:
1. `input/config_example.json`: For using pre-defined MPS files
2. `input/random_config_example.json`: For generating random instances
3. `input/batch_config_example.json`: For running multiple instances in batch

### Running Examples

1. Single Random Instance:
```sh
# Generate and solve a random instance with default parameters
qcongen input/random_config_example.json

# Generate and solve with quantum algorithm and custom parameters
qcongen input/random_config_example.json --tau 0.1 --max-iters 2000

# Generate and solve with classical solver
qcongen input/random_config_example.json --ref
```

2. Batch Processing:
```sh
# Run multiple instances in batch
qcongen input/batch_config_example.json

# Run batch with custom parameters
qcongen input/batch_config_example.json --tau 0.1 --max-iters 2000

# Run batch with classical solver
qcongen input/batch_config_example.json --ref
```

When using random instances:
1. The instance is generated at runtime
2. The MPS file is saved in your results directory as `instance.mps`
3. The problem is solved using either the quantum algorithm or classical solver
4. All results and logs are saved in the same directory

### Available Problem Instances

The repository includes several pre-defined set partitioning problem instances:
- `problem10_40.mps`: Small instance (10 variables, 40 constraints)
- `problem15_60.mps`: Medium instance (15 variables, 60 constraints)
- `problem30_100.mps`: Large instance (30 variables, 100 constraints)

You can also generate random instances with custom parameters using the configuration file.

### Command Line Options

| Option               | Default Value         | Description |
|---------------------|----------------------|-------------|
| `config_file`       | (required)           | Path to configuration JSON file |
| `--tau, -t`         | `0.0`                | Threshold for adding constraints |
| `--max-iters, -m`   | `1000`               | Maximum number of iterations |
| `--ibm-token`       | None                 | IBM Quantum token (overrides IBM_TOKEN environment variable) |
| `--ref`             | False                | Use classical reference solver (OR-Tools) instead of quantum algorithm |

### Output Structure

For single runs:
```
results/
└── YYYYMMDD_HHMMSS/
    ├── run.log
    ├── debug.log
    └── instance.mps  # For random instances
```

For batch runs:
```
results/
└── batch_NAME_YYYYMMDD_HHMMSS/
    ├── 1/
    │   ├── config.json
    │   ├── instance.mps  # For random instances
    │   ├── run.log
    │   └── debug.log
    ├── 2/
    │   ├── config.json
    │   ├── instance.mps
    │   ├── run.log
    │   └── debug.log
    └── N/
        ├── config.json
        ├── run.log
        └── debug.log
```

Each run's `run.log` contains:
- Problem dimensions
- Number of variables and constraints
- Matrix density information
- Feasible solutions found
- Best solution updates
- Final results

## Project Structure

```
qcongen/
├── src/
│   └── qcongen/
│       ├── engine/          # Core algorithm implementation
│       │   └── constraint_gen.py
│       ├── io/             # Input/output handling
│       │   ├── config_reader.py
│       │   ├── input_reader.py
│       │   └── output_writer.py
│       ├── opt_objects/    # Optimization objects
│       │   ├── bin_lp.py
│       │   ├── ising.py
│       │   └── quantum_problem_qiskit.py
│       └── utils/          # Utilities
│           ├── logging.py
│           └── reference_partition.py
├── input/
│   ├── set_partition_mps/  # Set partitioning problem instances
│   ├── config_example.json
│   ├── random_config_example.json
│   └── batch_config_example.json
├── pyproject.toml         # Project & tool configuration
└── requirements.txt       # Dependencies
```

## Development

### Setup Development Environment

```sh
pip install -e .[dev]
# Or use Hatch (recommended)
hatch env create
```

### Code Quality Tools

#### Ruff (Fast Python Linter and Formatter)

```sh
hatch run lint:style    # Run linting
hatch run lint:fmt      # Format code
```

#### Type Checking

```sh
hatch run lint:typing   # Run type checking
```

### Using Hatch

```sh
hatch env create           # Create development environment
hatch run lint:style       # Check code style
hatch run lint:fmt         # Format code
hatch run lint:typing      # Run type checking
hatch build               # Build project
```

## License

This project is licensed under the MIT License.

